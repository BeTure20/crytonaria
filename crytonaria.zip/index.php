<?php
require_once ('controllers/ym_class.php');

$ym->require_page("controllers/header.php");

$ym->getpages();

$ym->require_page("controllers/footer.php");
?>