
        <div class="wrapper landing_wrapper_content">
            <div class="container h-100">
                <div class="row h-100 align-items-center justify-content-between">
                    <div class="col-md-7  pl-0">
                        <h2>Exchange cryptocurrency <span class="text_colored">at the best rate</span></h2>
                        <p>Bitcoin Name HERE is a cryptocurrency and worldwide payment system. It is the first decentralized digital currency, as the system works without a central bank or single. Transfer from one wallet to another within seconds. It's that simple..</p>
                        <a class="btn_default" href="#">Join Us</a>
                    </div>
                    <div class="col-md-4 pl-0">
                        <div class="landing_countdown">
                            <p class="landing_cd_title">Bitbase Per-Sale <br> (With 30% Bonus) Ends in <br> August, 30th</p>
                            <ul id="countdown">
                                <li>
                                    <span id="days_l" class="time_counter"></span> <br>
                                    <span class="counter_text">Days</span>
                                </li>
                                <li>
                                    <span id="hours_l" class="time_counter"></span> <br>
                                    <span class="counter_text">Hours</span>
                                </li>
                                <li>
                                    <span id="minutes_l" class="time_counter"></span> <br>
                                    <span class="counter_text">Miniutes</span>
                                </li>
                                <li>
                                    <span id="seconds_l" class="time_counter"></span> <br>
                                    <span class="counter_text">Second</span>
                                </li>
                            </ul>
                            <div class="landing_option">
                                <span class="landing_line_info_left">Per-Sale</span>
                                <span class="landing_line_info_center">Soft-Cap</span>
                                <span class="landing_line_info_right">Bonus</span>
                                <p class="landing_line_map"><span></span></p>
                            </div>
                            <p class="landing_cd_subtitle">37M9275K Token Available<br>
                            <span class="text_colored">2.05 USD</span>
                            </p>
                            <a href="#" class="btn_default">Buy Token</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="work_wrapper" class="btc_excng_wrapper">
        <div class="container">
            <div class="row">
                <div class="col">
                    <div class="btc_excng_wrapper_slider">
                        
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row no-gutters">
                <div class="col">
                    <div class="btc_excng_wrapper_bottom">
                        <div class="btc_excng_wrapper_header">
                            <div class="container">
                                <div class="row">
                                    <div class="col">
                                        <p class="btc_excng_wrapper_header_left">Transfer from one wallet to another within seconds. It's that simple</p>
                                        <div class="btc_excng_wrapper_header_right align-middle">
                                            <div><p>Buy Bitcoin with Credit Card</p></div>
                                            <div class="border_left_1">
                                                <a href="#"><img src="https://www.angfuz.com/bitbase/html/img/visa.png" alt=""></a>
                                            </div>
                                            <div class="border_left_1">
                                                <a href="#"><img src="https://www.angfuz.com/bitbase/html/img/ms_card.png" alt=""></a>
                                            </div>
                                            <div class="border_left_1">
                                                <a href="#"><img src="https://www.angfuz.com/bitbase/html/img/paypal.png" alt=""></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="btc_excng_wrapper_input">
                            <div class="container">
                                <form action="#">
                                    <div class="row btc_excng_wrapper_input_inner justify-content-center">
                                        <script type="text/javascript">
                                            /* Example in Node.js ES6 using request-promise, concepts should translate to your language of choice */
  
                                                const rp = require('request-promise');
                                                const requestOptions = {
                                                  method: 'GET',
                                                  uri: 'https://pro-api.coinmarketcap.com/v1/cryptocurrency/listings/latest',
                                                  qs: {
                                                    start: 1,
                                                    limit: 5000,
                                                    convert: 'USD'
                                                  },
                                                  headers: {
                                                    'X-CMC_PRO_API_KEY': 'c482a801-5b1d-4bb7-84ae-b9c7dc527961'
                                                  },
                                                  json: true,
                                                  gzip: true
                                                };

                                                rp(requestOptions).then(response => {
                                                  console.log('API call response:', response);
                                                }).catch((err) => {
                                                  console.log('API call error:', err.message);
                                                });
                                        </script>
                                        <div class="col-lg-5 col-md-12">
                                            <div class="row no-gutters">
                                                <div class="col-lg-9 col-md-10 col-sm-9 col-7">
                                                    <input type="text" placeholder="1000000">
                                                </div>
                                                <div class="col-lg-3 col-md-2 col-sm-3 col-5">
                                                    <select class="custom-select">
                                                        <option selected value="1">BTC</option>
                                                        <option value="2">ETH</option>
                                                        <option value="3">USD</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-5 col-md-12">
                                            <div class="row no-gutters">
                                                <div class="col-lg-9 col-md-10 col-sm-9 col-7">
                                                    <input type="text" placeholder="45194561151">
                                                </div>
                                                <div class="col-lg-3 col-md-2 col-sm-3 col-5">
                                                    <select class="custom-select">
                                                        <option selected value="1">BTC</option>
                                                        <option value="2">ETH</option>
                                                        <option value="3">USD</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-2 col-12">
                                            <button class="btn_default" data-toggle="modal" data-target="#lgoinprocess">Exchange</button>
                                            <!-- Modal -->
                                            <div class="modal fade" id="lgoinprocess" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                                              <div class="modal-dialog" role="document" >
                                                <div class="modal-content modal-lg" style="width: 100%;">
                                                  <div class="modal-body" >
                                                    <div class="form-group">
                                                        <h4 class="modal-title">Hi USER</h4>
                                                    </div>
                                                    <div class="form-group">
                                                        <button type="button" class="btn btn-warning btn-lg" ">I'm New User</button>
                                                    </div>
                                                    <div class="form-group">
                                                        <button type="button" class="btn btn-default btn-lg">I already have Account</button>
                                                    </div>
                                                  </div>
                                                </div>
                                              </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="wrapper service_wrapper">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-12 wow fadeInLeft" style="visibility: visible; animation-delay: 0.1s; animation-name: fadeInLeft;" data-wow-delay="0.1s">
                    <h2 class="service_title">We Have Build a Platform To Buy &amp; Sells Share</h2>
                    <p class="service_para_text"><span class="text_colored">Bitbase</span> is a cryptocurrency and worldwide payment system. It is the first decentralized digital currency, as the system works without a central bank or single administrator. The network is peer-to-peer and transactions</p>
                    <div class="service_subtitles">
                        <span class="bg_purple2">01</span>
                        <p>First Open our Browser Then Login/Singup Our Website <br> To Join With Us!</p>
                    </div>
                    <div class="service_subtitles">
                        <span class="bg_cyan3">02</span>
                        <p>To Need Any Information Contact Us. We Will Wait For <br> Your Feedback.</p>
                    </div>
                    <div class="service_subtitles">
                        <span class="bg_default">03</span>
                        <p>If You Need Any Help We Will Serve 24/7 <br> Please Join Us!</p>
                    </div>
                </div>
                <div class="col-lg-6 col-md-12">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="service_single_opt">
                                <img src="https://www.angfuz.com/bitbase/html/img/service_opt_img_01.png" alt="">
                                <h5 class="service_single_opt_title">Easy To Convert Usd</h5>
                                <p class="service_single_opt_subtitle">Transfer funds to Changelly from your wallet</p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="service_single_opt">
                                <img src="https://www.angfuz.com/bitbase/html/img/service_opt_img_02.png" alt="">
                                <h5 class="service_single_opt_title">Easy To Earn Bitcoin</h5>
                                <p class="service_single_opt_subtitle">Bitcoin is a cryptocurrency and worldwide payment system.</p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="service_single_opt">
                                <img src="https://www.angfuz.com/bitbase/html/img/service_opt_img_03.png" alt="">
                                <h5 class="service_single_opt_title">Easy To Transfer Bitcoin</h5>
                                <p class="service_single_opt_subtitle">Bitcoin is a cryptocurrency and worldwide payment system.</p>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="service_single_opt">
                                <img src="https://www.angfuz.com/bitbase/html/img/service_opt_img_04.png" alt="">
                                <h5 class="service_single_opt_title">Easy To Earn Bitcoin</h5>
                                <p class="service_single_opt_subtitle">Bitcoin is a cryptocurrency and worldwide payment system.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="wrapper ptb-60 partner_wrapper">
                    <div class="container">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="owl-carousel partner_slider">
                                    <div>
                                        <div class="service_single_opt">
                                            <h5>1</h5>
                                            <p class="service_single_opt_subtitle">Transfer funds to Changelly from your wallet.</p>
                                        </div>
                                    </div>
                                    <div>
                                        <div class="service_single_opt">
                                            <h5>2</h5>
                                            <p class="service_single_opt_subtitle">Searching the best available rate on the market.</p>
                                        </div>
                                    </div>
                                    <div>
                                        <div class="service_single_opt">
                                            <h5>3</h5>
                                            <p class="service_single_opt_subtitle">website name Exchanging at the best rate.</p>
                                        </div>
                                    </div>
                                    <div>
                                        <div class="service_single_opt">
                                            <h5>4</h5>
                                            <p class="service_single_opt_subtitle">charges a reasonable fee 0,5% from the final amount.</p>
                                        </div>
                                    </div>
                                    <div>
                                        <div class="service_single_opt">
                                            <h5>5</h5>
                                            <p class="service_single_opt_subtitle">website Funds are delivered to a recipient wallet.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
             </div>
            </div>
        </div>
    </div>
    <div class="wrapper opportunity_wrapper">
        <div class="container">
            <div class="row">
                <div class="col text-center">
                    <h2 class="wrapper_title">Our Opportunity</h2>
                    <img class="wrapper_title_img" src="https://www.angfuz.com/bitbase/html/img/Wrapper_title_divider.png" alt="">
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <h3 class="opportunity_title">We Are Very Trusty Brand Ever</h3>
                    <p class="text_colored opportunity_subtitle_01">If you had invested $10,000 in Bitcoin at the start of year, you would have had an approximate profit of $30,000 by August.</p>
                    <p class="opportunity_subtitle_02">Bitcoin is a cryptocurrency and worldwide payment system. It is the first decentralized digital currency, as the system works without a central bank or single administrator.</p>
                    <a class="btn_default" href="#">Register Now</a>
                </div>
                <div class="col-md-6 mt40">
                    <img class="img-fluid" src="https://www.angfuz.com/bitbase/html/img/chart_img.png" alt="">
                </div>
            </div>
        </div>
    </div>
    <div id="token_wrapper" class="wrapper dis_token_wrapper">
        <div class="container">
            <div class="row">
                <div class="col text-center">
                    <h2 class="wrapper_title">Distribution Our Token</h2>
                    <img class="wrapper_title_img" src="https://www.angfuz.com/bitbase/html/img/Wrapper_title_divider.png" alt="">
                </div>
            </div>
            <div class="row h-100 align-items-center justify-content-between">
                <div class="col-lg-7 col-md-12">
                    <div class="token_pie_chart">
                        <img class="img-fluid" src="https://www.angfuz.com/bitbase/html/img/pie_chart.png" alt="">
                        <img class="logo_icon" src="https://www.angfuz.com/bitbase/html/img/ce_bitcoin_icon.png" alt="">
                        <p class="pie_chart_txt1"><span>20%</span><br>Bitbase Marketing</p>
                        <p class="pie_chart_txt2"><span>15%</span><br>Bitbase Work</p>
                        <p class="pie_chart_txt3"><span>30%</span><br>Marketing Work</p>
                        <p class="pie_chart_txt4"><span>10%</span><br>Bitbase Market</p>
                        <p class="pie_chart_txt5"><span>40%</span><br>Bitbase Work</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-12 wow fadeInRight" style="visibility: visible; animation-delay: 0.1s; animation-name: fadeInRight;" data-wow-delay="0.1s">
                    <div class="token_info_item">
                        <div><span class="bg_pink"></span><p>20% Bitbase Marketing Platform</p></div>
                        <div><span class="bg_green2"></span><p>15% Bitbase Marketing Work</p></div>
                        <div><span class="bg_cyan2"></span><p>30% International Marketing Work</p></div>
                        <div><span class="bg_orange"></span><p>10% International Bitbase Marketing</p></div>
                        <div class="mb-0"><span class="bg_light_blue2"></span><p>40% International Bitbase Work</p></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="step_wrapper" class="wrapper steps_03_wrapper">
        <div class="container">
            <div class="row">
                <div class="col text-center">
                    <h2 class="wrapper_title">03 Easy Step</h2>
                    <img class="wrapper_title_img" src="https://www.angfuz.com/bitbase/html/img/Wrapper_title_divider.png" alt="">
                </div>
            </div>
            <div class="row">
                <div class="col-md-4 wow fadeInUp" style="visibility: visible; animation-delay: 0.1s; animation-name: fadeInUp;" data-wow-delay="0.1s">
                    <div class="steps_03_item">
                        <span class="steps_03_count">01</span>
                        <div class="steps_03_icon">
                            <img src="https://www.angfuz.com/bitbase/html/img/icons/money_b.png" alt="">
                        </div>
                        <h4 class="steps_03_title">Pass Free Registration</h4>
                        <p class="steps_03_subtitle">Bitcoin is a cryptocurrency and worldwide payment system. It is the first decentralized digital currency, as the system works.</p>
                    </div>
                </div>
                <div class="col-md-4 wow fadeInUp" style="visibility: visible; animation-delay: 0.3s; animation-name: fadeInUp;" data-wow-delay="0.3s">
                    <div class="steps_03_item">
                        <span class="steps_03_count">02</span>
                        <div class="steps_03_icon">
                            <img src="https://www.angfuz.com/bitbase/html/img/icons/bitcoin.png" alt="">
                        </div>
                        <h4 class="steps_03_title">Active Trading aAccount</h4>
                        <p class="steps_03_subtitle">Bitcoin is a cryptocurrency and worldwide payment system. It is the first decentralized digital currency, as the system works.</p>
                    </div>
                </div>
                <div class="col-md-4 wow fadeInUp" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInUp;" data-wow-delay="0.5s">
                    <div class="steps_03_item">
                        <span class="steps_03_count">03</span>
                        <div class="steps_03_icon">
                            <img src="https://www.angfuz.com/bitbase/html/img/icons/money_t.png" alt="">
                        </div>
                        <h4 class="steps_03_title">Enjoy Your Fund Going</h4>
                        <p class="steps_03_subtitle">Bitcoin is a cryptocurrency and worldwide payment system. It is the first decentralized digital currency, as the system works.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="roadmap_wrapper" class="wrapper road_map_wrapper">
        <div class="container">
            <div class="row">
                <div class="col text-center">
                    <h2 class="wrapper_title">Road Map</h2>
                    <img class="wrapper_title_img" src="https://www.angfuz.com/bitbase/html/img/Wrapper_title_divider.png" alt="">
                </div>
            </div>
            <div class="row">
                <div class="col text-center">
                    <div class="timeline">
                        <div class="timeline__wrap">
                            <div class="timeline__items">
                                <div class="timeline__item">
                                    <div class="timeline__content">
                                        <span class="vertical_divider"></span>
                                        <h2 class="text_colored">Nov 2016</h2>
                                        <p>The network is peer-to-peer <br> and transactions</p>
                                    </div>
                                </div>
                                <div class="timeline__item">
                                    <div class="timeline__content">
                                        <h2 class="text_colored">Jan 2017</h2>
                                        <p>The network is peer-to-peer <br> and transactions</p>
                                        <span class="vertical_divider"></span>
                                    </div>
                                </div>
                                <div class="timeline__item">
                                    <div class="timeline__content">
                                        <span class="vertical_divider"></span>
                                        <h2 class="text_colored">Dec 2018</h2>
                                        <p>The network is peer-to-peer <br> and transactions</p>
                                    </div>
                                </div>
                                <div class="timeline__item">
                                    <div class="timeline__content">
                                        <h2 class="text_colored">Mar 2018</h2>
                                        <p>The network is peer-to-peer <br> and transactions</p>
                                        <span class="vertical_divider"></span>
                                    </div>
                                </div>
                                <div class="timeline__item">
                                    <div class="timeline__content">
                                        <span class="vertical_divider"></span>
                                        <h2 class="text_colored">Nov 2016</h2>
                                        <p>The network is peer-to-peer <br> and transactions</p>
                                    </div>
                                </div>
                                <div class="timeline__item">
                                    <div class="timeline__content">
                                        <h2 class="text_colored">Jan 2017</h2>
                                        <p>The network is peer-to-peer <br> and transactions</p>
                                        <span class="vertical_divider"></span>
                                    </div>
                                </div>
                                <div class="timeline__item">
                                    <div class="timeline__content">
                                        <span class="vertical_divider"></span>
                                        <h2 class="text_colored">Dec 2018</h2>
                                        <p>The network is peer-to-peer <br> and transactions</p>
                                    </div>
                                </div>
                                <div class="timeline__item">
                                    <div class="timeline__content">
                                        <h2 class="text_colored">Mar 2018</h2>
                                        <p>The network is peer-to-peer <br> and transactions</p>
                                        <span class="vertical_divider"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="faq_wrapper" class="wrapper faq_wrapper">
        <div class="container">
            <div class="row">
                <div class="col text-center">
                    <h2 class="wrapper_title">Frequently Asked Question</h2>
                    <img class="wrapper_title_img" src="https://www.angfuz.com/bitbase/html/img/Wrapper_title_divider.png" alt="">
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <a href="https://www.youtube.com/watch?v=7GB4JQKHPrU" class="popup-youtube">
                        <div class="faq_video">
                            <img src="https://www.angfuz.com/bitbase/html/img/play_icon.png" alt="">
                        </div>
                    </a>
                </div>
                <div class="col-md-6">
                    <div class="accordion" id="accordionExample">
                        <div class="card">
                            <div class="card-header" id="headingOne">
                                <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">What Is Bitbase? <span class="fa fa-angle-down"></span></button>
                            </div>
                            <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
                                <div class="card-body">
                                    Bitcoin is a cryptocurrency and worldwide payment system. It is the first decentralized digital currency, as the system works without a central bank or single administrator.
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" id="headingTwo">
                                <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">How To Create LBL Wallet? <span class="fa fa-angle-right"></span></button>
                            </div>
                            <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
                                <div class="card-body">
                                    Bitcoin is a cryptocurrency and worldwide payment system. It is the first decentralized digital currency, as the system works without a central bank or single administrator.
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" id="headingThree">
                                <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="true" aria-controls="collapseThree">How To Earn Bitcoin? <span class="fa fa-angle-right"></span></button>
                            </div>
                            <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
                                <div class="card-body">
                                    Bitcoin is a cryptocurrency and worldwide payment system. It is the first decentralized digital currency, as the system works without a central bank or single administrator.
                                </div>
                            </div>
                        </div>
                        <div class="card mb-0">
                            <div class="card-header" id="headingFour">
                                <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseFour" aria-expanded="true" aria-controls="collapseFour">How Can I Make A Good Skill? <span class="fa fa-angle-right"></span></button>
                            </div>
                            <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordionExample">
                                <div class="card-body">
                                    Bitcoin is a cryptocurrency and worldwide payment system. It is the first decentralized digital currency, as the system works without a central bank or single administrator.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="wrapper token_wrapper">
        <div class="container">
            <div class="row">
                <div class="col text-center">
                    <h2 class="wrapper_title">Token</h2>
                    <img class="wrapper_title_img" src="https://www.angfuz.com/bitbase/html/img/Wrapper_title_divider.png" alt="">
                </div>
            </div>
            <div class="token_counter_details">
                <div class="row">
                    <div class="col-lg-5 col-md-12">
                        <div class="taken_counter">
                            <div class="token_line_map">
                                <ul class="token_line_info_left">
                                    <li>02M</li>
                                    <li class="vertical_divider"></li>
                                    <li>Soft Cap</li>
                                </ul>
                                <p class="token_line"><span></span></p>
                                <ul class="token_line_info_right">
                                    <li>20M</li>
                                    <li class="vertical_divider"></li>
                                    <li>Hard Cap</li>
                                </ul>
                            </div>
                            <ul class="timeout_counter">
                                <li>
                                    <span id="days" class="time_counter"></span>
                                    <span class="counter_text">Days</span>
                                </li>
                                <li class="vertical_divider"></li>
                                <li>
                                    <span id="hours" class="time_counter"></span>
                                    <span class="counter_text">Hours</span>
                                </li>
                                <li class="vertical_divider"></li>
                                <li>
                                    <span id="minutes" class="time_counter"></span>
                                    <span class="counter_text">Miniutes</span>
                                </li>
                                <li class="vertical_divider"></li>
                                <li>
                                    <span id="seconds" class="time_counter"></span>
                                    <span class="counter_text">Sceonds</span>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-7 col-md-12">
                        <div class="taken_details">
                            <p class="token_details_text">Bitcoin is a cryptocurrency and worldwide payment system. It is the first decentralized digital currency, as the system works without a central bank or single administrator.</p>
                            <div class="row no-gutters">
                                <div class="col-md-6 col-12">
                                    <div class="token_details_single_info">
                                        <p>Start</p>
                                        <span>Jan 8, 2018 (9:00 AM GMT)</span>
                                    </div>
                                </div>
                                <div class="col-md-6 col-12">
                                    <div class="token_details_single_info">
                                        <p>End</p>
                                        <span>Feb 8, 2019 (9:00 AM GMT)</span>
                                    </div>
                                </div>
                                <div class="col-md-6 col-12">
                                    <div class="token_details_single_info mb-0 mb-30">
                                        <p>End</p>
                                        <span>Feb 8, 2019 (9:00 AM GMT)</span>
                                    </div>
                                </div>
                                <div class="col-md-6 col-12">
                                    <div class="token_details_single_info mb-0">
                                        <p>Number of tokens for sale</p>
                                        <span>100,000,000</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="total_num_of_tokens">
                <div class="row no-gutters">
                    <div class="col-md-6">
                        <div class="tno_token_left">
                            <p>Total Numbers Of Tokens</p>
                            <h1>100,000,000</h1>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="tno_token_right">
                            <p>1 Crypion Token Price</p>
                            <h1>0.112.00 BTC</h1>
                        </div>
                    </div>
                </div>
            </div>
            <div class="token_wrapper_bottom">
                <div class="row no-gutters">
                    <div class="col-md-6">
                        <p>ICO per-sale (with 20% bonus) ends in August, 20th</p>
                        <p class="text_colored">$12,026,615</p>
                    </div>
                    <div class="col-md-6 pl-25">
                        <p>We Accept: BTC, ETH, LTC, BCH, Wire</p>
                        <a class="btn_default" href="#">Buy Token</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="exchange_wrapper" class="wrapper current_exchange_wrapper">
        <div class="container">
            <div class="row">
                <div class="col text-center">
                    <h2 class="wrapper_title">Current Exchange</h2>
                    <img class="wrapper_title_img" src="https://www.angfuz.com/bitbase/html/img/Wrapper_title_divider.png" alt="">
                </div>
            </div>
            <div class="row">
                <div class="col-lg-3 col-md-6 col-12 text-center">
                    <div class="cur_ex_item">
                        <div class="cur_ex_icon"><img src="https://www.angfuz.com/bitbase/html/img/ce_dash_icon.png" alt=""></div>
                        <div class="cur_ex_divider"><img src="https://www.angfuz.com/bitbase/html/img/ce_divider.png" alt=""></div>
                        <div class="exchange_price">
                            <h5>Dash</h5>
                            <p><span class="text_colored">$0010.253</span>+30.52YTD</p>
                            <a class="btn_default" href="#">Buy Now</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-12 text-center">
                   <div class="cur_ex_item">
                        <div class="cur_ex_icon"><img src="https://www.angfuz.com/bitbase/html/img/ce_ripple_icon.png" alt=""></div>
                        <div class="cur_ex_divider"><img src="https://www.angfuz.com/bitbase/html/img/ce_divider.png" alt=""></div>
                        <div class="exchange_price">
                            <h5>Ripple</h5>
                            <p><span class="text_colored">$0010.253</span>+30.52YTD</p>
                            <a class="btn_default" href="#">Buy Now</a>
                        </div>
                   </div>
                </div>
                <div class="col-lg-3 col-md-6 col-12 text-center">
                    <div class="cur_ex_item">
                        <div class="cur_ex_icon"><img src="https://www.angfuz.com/bitbase/html/img/ce_dash_icon.png" alt=""></div>
                        <div class="cur_ex_divider"><img src="https://www.angfuz.com/bitbase/html/img/ce_divider.png" alt=""></div>
                        <div class="exchange_price">
                            <h5>USD</h5>
                            <p><span class="text_colored">$0010.253</span>+30.52YTD</p>
                            <a class="btn_default" href="#">Buy Now</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-12 text-center">
                    <div class="cur_ex_item">
                        <div class="cur_ex_icon"><img src="https://www.angfuz.com/bitbase/html/img/ce_bitcoin_icon.png" alt=""></div>
                        <div class="cur_ex_divider"><img src="https://www.angfuz.com/bitbase/html/img/ce_divider.png" alt=""></div>
                        <div class="exchange_price">
                            <h5>Bit Coin</h5>
                            <p><span class="text_colored">$0010.253</span>+30.52YTD</p>
                            <a class="btn_default" href="#">Buy Now</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="wrapper customer_wrapper">
        <div class="container">
            <div class="row text-center justify-content-between">
                <div class="col-md-3">
                    <div class="coundown_single">
                        <h2><span class="counter">40,000</span><span>+</span></h2>
                        <p>BitCoin Sale</p>
                    </div>
                </div>
                <div class="col-md-5">
                    <div class="coundown_single lr_bordered">
                        <h2><span class="counter">70,000</span><span>+</span></h2>
                        <p>happy customers</p>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="coundown_single">
                        <h2><span class="counter">70,000</span><span>+</span></h2>
                        <p>Trusted Vendors</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="blog_wrapper" class="wrapper blog_wrapper">
        <div class="container">
            <div class="row">
                <div class="col text-center">
                    <h2 class="wrapper_title">Latest News</h2>
                    <img class="wrapper_title_img" src="https://www.angfuz.com/bitbase/html/img/Wrapper_title_divider.png" alt="">
                </div>
            </div>
            <div class="owl-carousel blog_slider">
                <div class="blog_item">
                    <div class="card border-0">
                        <div class="card_head">
                            <div class="card_img">
                                <img class="card-img-top" src="https://www.angfuz.com/bitbase/html/img/blog_01.jpg" alt="">
                            </div>
                        </div>
                        <div class="card-body">
                            <span>
                                <a href="home-one.html" class="post_by">Admin </a> 
                                <strong class="date"> 19 June , 2018</strong> 
                            </span>
                            <h4 class="blog_title"><a href="https://www.angfuz.com/bitbase/html/single-blog.html">Bitbase Marketplace Pro</a></h4>
                            <p class="bolg_sm_details">Bitcoin is a cryptocurrency and worldwide payment system. It is the first decentralized digital currency.</p>
                            <a class="btn_default" href="home-one.html">Read More</a>
                        </div>
                    </div>
                </div>
                <div class="blog_item">
                    <div class="card border-0">
                        <div class="card_head">
                            <div class="card_img">
                                <img class="card-img-top" src="https://www.angfuz.com/bitbase/html/img/blog_02.jpg" alt="">
                            </div>
                        </div>
                        <div class="card-body">
                            <span>
                                <a href="home-one.html" class="post_by">Admin </a> 
                                <strong class="date"> 19 June , 2018</strong> 
                            </span>
                            <h4 class="blog_title"><a href="https://www.angfuz.com/bitbase/html/single-blog.html">Bitbase Marketplace Pro</a></h4>
                            <p class="bolg_sm_details">Bitcoin is a cryptocurrency and worldwide payment system. It is the first decentralized digital currency.</p>
                            <a class="btn_default" href="home-one.html">Read More</a>
                        </div>
                    </div>
                </div>
                <div class="blog_item">
                    <div class="card border-0">
                        <div class="card_head">
                            <div class="card_img">
                                <img class="card-img-top" src="https://www.angfuz.com/bitbase/html/img/blog_03.jpg" alt="">
                            </div>
                        </div>
                        <div class="card-body">
                            <span>
                                <a href="home-one.html" class="post_by">Admin </a> 
                                <strong class="date"> 19 June , 2018</strong> 
                            </span>
                            <h4 class="blog_title"><a href="https://www.angfuz.com/bitbase/html/single-blog.html">Bitbase Marketplace Pro</a></h4>
                            <p class="bolg_sm_details">Bitcoin is a cryptocurrency and worldwide payment system. It is the first decentralized digital currency.</p>
                            <a class="btn_default" href="home-one.html">Read More</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="wrapper ptb-60 partner_wrapper">
        <div class="container">
            <div class="row align-items-center">
                <div class="col">
                    <div class="owl-carousel partner_slider">
                        <div><img src="https://www.angfuz.com/bitbase/html/img/partner_01.png" alt=""></div>
                        <div><img src="https://www.angfuz.com/bitbase/html/img/partner_02.png" alt=""></div>
                        <div><img src="https://www.angfuz.com/bitbase/html/img/partner_03.png" alt=""></div>
                        <div><img src="https://www.angfuz.com/bitbase/html/img/partner_04.png" alt=""></div>
                        <div><img src="https://www.angfuz.com/bitbase/html/img/partner_05.png" alt=""></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="contact_wrapper" class="wrapper contact_wrapper">
        <div class="container">
            <div class="row">
                <div class="col text-center">
                    <h2 class="wrapper_title">Contact Us</h2>
                    <img class="wrapper_title_img" src="https://www.angfuz.com/bitbase/html/img/Wrapper_title_divider.png" alt="">
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <!-- Google Map Start Here -->
                    <div id="gmap" class="gmap-area"></div>
                </div>
                <div class="col-md-6">
                    <form class="contact_form" action="#">
                        <input type="text" name="name" placeholder="Name">
                        <input type="email" name="email" placeholder="Email Address">
                        <input type="text" name="phone" placeholder="Phone">
                        <textarea name="message" placeholder="Message"></textarea>
                        <button class="btn_default" type="submit">Get Started Now</button>
                    </form>
                </div>
            </div>
        </div>
    </div>