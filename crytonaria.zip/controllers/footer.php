<div id="footer_wrapper" class="wrapper footer_wrapper background-image" data-src="https://www.angfuz.com/bitbase/html/img/footer-bg.jpg">
        <div class="container">
            <div class="row no-gutters justify-content-between">
                <div class="col-lg-3 col-md-12">
                    <div><a href="home-one.html"><img class="footer_logo" src="https://www.angfuz.com/bitbase/html/img/logo.png" alt=""></a></div>
                    <p>Bitcoin is a cryptocurrency and worldwide payment system. It is the first decentralized digital currency, as the system works without a central bank.</p>
                    <div class="row no-gutters">
                        <div class="col">
                            <p><i class="fa fa-map-marker text_colored"></i> Address: 557 Cyan Avenue, Suite <br><span style="padding-left:85px">65 New York, CA 9008</span></p>
                        </div>
                    </div>
                    <div class="row no-gutters">
                        <div class="col">
                            <p><i class="fa fa-phone text_colored"></i> Phone: (123) 456-7890</p>
                        </div>
                    </div>
                    <div class="row no-gutters">
                        <div class="col">
                            <p><i class="fa fa-envelope text_colored"></i> Email: bitbase@gmail.com</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-12 footer_middle">
                    <h5 class="footer_header">Information</h5>
                    <ul>
                        <li><a href="#"><i class="fa fa-angle-right"></i> Payment Option</a></li>
                        <li><a href="#"><i class="fa fa-angle-right"></i> How It Work</a></li>
                        <li><a href="#"><i class="fa fa-angle-right"></i> Master Card Verification Guide</a></li>
                        <li><a href="#"><i class="fa fa-angle-right"></i> Developer Platform Guide</a></li>
                        <li><a href="#"><i class="fa fa-angle-right"></i> Bitcoin Earn</a></li>
                        <li><a href="#"><i class="fa fa-angle-right"></i> Buy &amp; Sell Digital Currency</a></li>
                    </ul>
                </div>
                <div class="col-lg-3 col-md-12">
                    <h5 class="footer_header">Newsletter</h5>
                        <form class="row no-gutters">
                            <div class="col-12">
                                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quaerat rerum doloremque totam culpa eius distinctio laudantium architecto repellat sed deleniti, ullam quisquam nobis placeat nisi.</p>
                                <div class="subscribe-form">
                                    <input type="text" placeholder="Email Address">
                                    <button type="submit" class="btn_default"><i class="fa fa-paper-plane-o"></i></button>
                                </div>
                            </div>
                        </form>
                    <div class="footer_socials">
                        <ul>
                            <li><a href="#"><i class="fa fa-facebook-f"></i></a></li>
                            <li><a href="#"><i class="fa fa-skype"></i></a></li>
                            <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                            <li><a href="#"><i class="fa fa-youtube-play"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer_bottom">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-12">
                    <p>Copyright @2018 Design By <a href="#" class="text_colored">Ntech</a></p>
                </div>
                <div class="col-lg-6 col-md-12">
                    <ul class="text-lg-right text-md-center">
                        <li><a href="#">Home</a></li>
                        <li><a href="#">Buy or Sell</a></li>
                        <li><a href="#">Privacy Policy</a></li>
                        <li><a href="#">Faq</a></li>
                        <li><a href="#">Contact</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    
    <!-- ========  All JS Here ========  -->
    <script src="assets/js/jquery-3.2.1.min.js" type="text/javascript"></script>
    <script src="assets/js/vendor/js/popper.min.js" type="text/javascript"></script>
    <script src="assets/js/vendor/bootstrap.min.js" type="text/javascript"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCcvAXp35fi4q7HXm7vcG9JMtzQbMzjRe8"></script>  
    <script src="assets/js/vendor/gmaps.js"></script>  
    <script src="assets/js/vendor/scrollup.js" type="text/javascript"></script>
    <script src="assets/js/vendor/jquery.magnific-popup.js" type="text/javascript"></script>
    <script src="assets/js/vendor/plugins.js" type="text/javascript"></script>
    <script src="assets/js/vendor/vegas.min.js" type="text/javascript"></script>
    <script src="assets/js/vendor/token_countdown.js" type="text/javascript"></script>
    <script src="assets/js/vendor/landing_countdown.js" type="text/javascript"></script>
    <script src="assets/js/vendor/wow.min.js" type="text/javascript"></script>
    <script src="assets/js/vendor/jquery.nice-select.min.js" type="text/javascript"></script>
    <script src="assets/js/main.js" type="text/javascript"></script>
</body>

</html>
