<!DOCTYPE html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Bitbase - Bitcoin and Cryptocurrency</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="https://www.angfuz.com/bitbase/html/img/favicon.png" />
    <link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,600,700%7CMuli:300,400,600,700,800" rel="stylesheet">
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="assets/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="assets/css/timeline.min.css" rel="stylesheet" type="text/css">
    <link href="assets/css/magnific-popup.css" rel="stylesheet" type="text/css">
    <link href="assets/css/owl.carousel.min.css" rel="stylesheet" type="text/css">
    <link href="assets/css/vegas.min.css" rel="stylesheet" type="text/css">
    <link href="assets/css/animate.css" rel="stylesheet" type="text/css" media="all">
    <link href="assets/css/nice-select.css" rel="stylesheet" type="text/css" media="all">
    <link href="assets/css/style.css" rel="stylesheet" type="text/css">
    <link href="assets/css/responsive.css" rel="stylesheet" type="text/css">
</head>

<body>    
    <div class="loader">
        <div id="loader_wrap">
            <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="200px" height="200px" viewBox="100 100 400 400" xml:space="preserve">
            <filter id="dropshadow" height="130%">
                <feGaussianBlur in="SourceAlpha" stdDeviation="5"/>
                <feOffset dx="0" dy="0" result="offsetblur"/>
                <feFlood flood-color="red"/>
                <feComposite in2="offsetblur" operator="in"/>
                <feMerge>
                    <feMergeNode/>
                    <feMergeNode in="SourceGraphic"/>
                </feMerge>
            </filter>
            <path class="path" style="filter:url(#dropshadow)" fill="#000000" d="M446.089,261.45c6.135-41.001-25.084-63.033-67.769-77.735l13.844-55.532l-33.801-8.424l-13.48,54.068
            c-8.896-2.217-18.015-4.304-27.091-6.371l13.568-54.429l-33.776-8.424l-13.861,55.521c-7.354-1.676-14.575-3.328-21.587-5.073
            l0.034-0.171l-46.617-11.64l-8.993,36.102c0,0,25.08,5.746,24.549,6.105c13.689,3.42,16.159,12.478,15.75,19.658L208.93,357.23
            c-1.675,4.158-5.925,10.401-15.494,8.031c0.338,0.485-24.579-6.134-24.579-6.134l-9.631,40.468l36.843,9.188
            c8.178,2.051,16.209,4.19,24.098,6.217l-13.978,56.17l33.764,8.424l13.852-55.571c9.235,2.499,18.186,4.813,26.948,6.995
            l-13.802,55.309l33.801,8.424l13.994-56.061c57.648,10.902,100.998,6.502,119.237-45.627c14.705-41.979-0.731-66.193-31.06-81.984
            C425.008,305.984,441.655,291.455,446.089,261.45z M368.859,369.754c-10.455,41.983-81.128,19.285-104.052,13.589l18.562-74.404
            C306.28,314.65,379.774,325.975,368.859,369.754z M379.302,260.846c-9.527,38.187-68.358,18.781-87.442,14.023l16.828-67.489
            C327.767,212.14,389.234,221.02,379.302,260.846z"/>
            </svg>
        </div>
    </div>

    <div id="home_wrapper" class="landing_wrapper home_one_landing">
        <div class="header_bottom">
            <div class="container">
                <div class="row">
                    <div class="col-md-2 col-6">
                        <a href="#home_wrapper" class="logo">
                            <img src="https://www.angfuz.com/bitbase/html/img/logo.png" alt="BitBase">
                        </a>
                    </div>
                    <div class="col-md-10 col-6">
                        <nav>
                            <ul>
                                <li><a class="smooth_scroll" href="#work_wrapper">How It Work</a></li>
                                <li><a class="smooth_scroll" href="#faq_wrapper">FAQ</a></li>
                                <li><a class="smooth_scroll" href="#step_wrapper">Service</a></li>
                                <li><a class="smooth_scroll" href="#contact_wrapper">Cantact Us</a></li>
                                <li><a class="smooth_scroll" href="#exchange_wrapper">Login</a></li>
                                <li><a class="smooth_scroll" href="#roadmap_wrapper">SignUp</a></li>
                                <li class="menu_close_btn"><i class="fa fa-close"></i></li>
                            </ul>
                        </nav>
						<div class="menu_btn">
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
