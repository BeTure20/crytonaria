<?php 

class main{
	public function redirect_to($location = NULL){
		if($location!=NULL){
			header("Location:{$location}");
			exit;
		}
	}
	
	public function require_page($path=""){
		if($path != ""){
			require_once($path);
		}
	}

	public function getpages(){
		if(!isset($_GET['p'])){
			$this->require_page("views/home.php");
		} else {
			$get = @$_GET['p'];
			switch($get){
				case "about":
					$this->require_page('views/about.php');
					break;
				case ".":
					$this->require_page('views/.');
					break;
				case "contact":
					$this->require_page('views/contact.php');
					break;
				case "events":
					$this->require_page('views/events.php');
					break;
				case "gallery":
					$this->require_page('views/gallery.php');
					break;
				case "team":
					$this->require_page('views/team.php');
					break;
				case "faqs":
					$this->require_page('views/faqs.php');
					break;
				case "terms-condition":
					$this->require_page('views/terms.php');
					break;
				case "warning":
					$this->require_page('views/warning.php');
					break;
				case "blog":
					$this->require_page('views/blog.php');
					break;
				default:
					$this->require_page('views/404.php');
					break;
			}
		}
	}
	
	public function getReferal(){
		@$get_ref = $_GET['ref'];
		if(isset($get_ref)  && $get_ref !==""){
			echo $get_ref;
		} elseif(!isset($get_ref) && $get_ref !== ""){
			echo  "cashbackz";
		} 
	}
	
	
}

$ym = new main();
?>